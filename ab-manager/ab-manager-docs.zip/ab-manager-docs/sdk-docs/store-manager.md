# ab-manager-store

Vuex管理器，控制交易的数据。

1.引入

```js
// main.js
import store from './store'
import { StoreManager }  from 'ab-manager-store'

StoreManager.init(store)
```

```js
//store.js
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
const store = new Vuex.Store({
    state: {
      mount:1
    },
    getters:{
    },
    mutations: {
    },

  })
export default store;
```

2.使用：
```js
//first 模块
const first = {
    namespaced: true,
    name:"first",
    state() {
      return {
        count: 0
      }
    },
    getters: {
      getCount: (state, getters, rootSate) => {
        return state.count
      } 
    },
    mutations: {
      setCount(state, number) {
        state.count = number
      }   
    }
  }
  export default first
```

```js
// 当前.vue文件 

// 获取子模块数据
// 模块名   类型:getters,mutations,actions  调用名称  参数
//dynamicDispatch(dynamicModuleName, type, name, arg);

// 获取全局数据
// 类型:getters,mutations,actions  调用名称  参数
//dispatch: function (type, name, arg)

// 置回初始数据
// StoreManager.clear("first")
<script>
import {StoreManager} from "ab-manager-store";

export default {
    data(){
        return {
            count:''
        }
    }
  created() {
    this.count = StoreManager.dynamicDispatch("first", "getters", "getCount"); //0
  }
}
</script>
```


| 事件     | 参数     | 类型 | 说明 |
| -----| -------- | --- | --- |
| dispatch | (type, name, arg) | string | 获取全局数据方法，参数为：类型:getters,mutations,actions  调用名称  参数 |
| dynamicDispatch | (dynamicModuleName, type, name, arg) | string |获取子模块数据方法，参数为：模块名   类型:getters,mutations,actions  调用名称  参数 |
| clear | (dynamicModuleName，state) | string | 交易完成后可调用clear方法将数据置为初始值 需要传入指定模块名，状态值，主模块只需传入状态值，空参则置空所有|